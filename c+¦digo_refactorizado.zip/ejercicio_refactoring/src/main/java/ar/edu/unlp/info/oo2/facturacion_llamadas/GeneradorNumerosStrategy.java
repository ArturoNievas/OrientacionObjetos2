package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.Collections;
import java.util.SortedSet;

public abstract class GeneradorNumerosStrategy {
	public static GeneradorNumerosStrategy crearGenerador(String tipo) {
		switch (tipo) {
		case "ultimo":
			return new GeneradorNumerosStrategyUltimo();
		case "primero":
			return new GeneradorNumerosStrategyPrimero();
		case "random":
			return new GeneradorNumerosStrategyRandom();
		default:
			return new NullGeneradorNumerosStrategy();
		}
	}

	protected abstract String seleccionarLineaLibre(SortedSet<String> lineas);

	public String liberarLinea(SortedSet<String> lineas) {
		String linea = this.seleccionarLineaLibre(Collections.unmodifiableSortedSet(lineas));
		lineas.remove(linea);
		return linea;
	}
}
