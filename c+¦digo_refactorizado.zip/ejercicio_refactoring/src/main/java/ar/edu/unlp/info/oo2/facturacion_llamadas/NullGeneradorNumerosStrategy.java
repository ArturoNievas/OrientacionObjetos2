package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.SortedSet;

public class NullGeneradorNumerosStrategy extends GeneradorNumerosStrategy {
	@Override
	public String liberarLinea(SortedSet<String> lineas) {
		return null;
	}

	@Override
	protected String seleccionarLineaLibre(SortedSet<String> lineas) {
		return null;
	}
}
