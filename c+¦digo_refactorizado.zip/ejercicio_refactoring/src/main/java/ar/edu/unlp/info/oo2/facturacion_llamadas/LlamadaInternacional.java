package ar.edu.unlp.info.oo2.facturacion_llamadas;

public class LlamadaInternacional extends Llamada {
	private static double PRECIO_POR_SEG = 150;
	private static double PRECIO_ESTAB_LLAMADA = 50;

	protected LlamadaInternacional(String origen, String destino, int duracion) {
		super(origen, destino, duracion);
	}

	@Override
	protected double getMontoPorSegundo() {
		return LlamadaInternacional.PRECIO_POR_SEG;
	}

	@Override
	protected double getMontoPorEstablecerLlamada() {
		return LlamadaInternacional.PRECIO_ESTAB_LLAMADA;
	}
}
