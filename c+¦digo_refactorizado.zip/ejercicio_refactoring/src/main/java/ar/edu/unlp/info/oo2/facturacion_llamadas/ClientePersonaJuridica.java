package ar.edu.unlp.info.oo2.facturacion_llamadas;

public class ClientePersonaJuridica extends Cliente {
	private static double DESCUENTO_LLAMADAS = 0.15;

	private String cuit;

	protected ClientePersonaJuridica(String razonSocial, String numeroTelefono, String cuit) {
		super(razonSocial, numeroTelefono);
		this.cuit = cuit;
	}

	public String getCuit() {
		return cuit;
	}

	@Override
	public double getDescuentoEnLlamadas() {
		return ClientePersonaJuridica.DESCUENTO_LLAMADAS;
	}
}
