package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.SortedSet;

public class GeneradorNumerosStrategyPrimero extends GeneradorNumerosStrategy {
	@Override
	protected String seleccionarLineaLibre(SortedSet<String> lineas) {
		return lineas.first();
	}
}
