package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.ArrayList;
import java.util.List;

public class Empresa {
	private List<Cliente> clientes;
	private GestorNumerosDisponibles guia;

	public Empresa() {
		this.clientes = new ArrayList<Cliente>();
		this.guia = new GestorNumerosDisponibles();
	}

	public boolean agregarNumeroTelefono(String lineaTelefonica) {
		return this.guia.agregarNumeroTelefono(lineaTelefonica);
	}

	public String obtenerNumeroLibre() {
		return this.guia.obtenerNumeroLibre();
	}

	private Cliente agregarCliente(Cliente cliente) {
		clientes.add(cliente);
		return cliente;
	}

	public Cliente registrarPersonaFisica(String dni, String nombre) {
		return this.agregarCliente(Cliente.crearPersonaFisica(nombre, this.obtenerNumeroLibre(), dni));
	}

	public Cliente registrarPersonaJuridica(String cuit, String razonSocial) {
		return this.agregarCliente(Cliente.crearPersonaJuridica(razonSocial, this.obtenerNumeroLibre(), cuit));
	}

	public Llamada registrarLlamadaNacional(Cliente origen, Cliente destino, int duracion) {
		return origen.agregarLlamada(Llamada.crearLlamadaNacional(origen, destino, duracion));
	}

	public Llamada registrarLlamadaInternacional(Cliente origen, Cliente destino, int duracion) {
		return origen.agregarLlamada(Llamada.crearLlamadaInternacional(origen, destino, duracion));
	}

	public double calcularMontoTotalLlamadas(Cliente cliente) {
		return cliente.calcularMontoTotalLlamadas();
	}

	public int cantidadDeUsuarios() {
		return this.clientes.size();
	}

	public boolean existeUsuario(Cliente persona) {
		return this.clientes.contains(persona);
	}

	public GestorNumerosDisponibles getGestorNumeros() {
		return this.guia;
	}
}
