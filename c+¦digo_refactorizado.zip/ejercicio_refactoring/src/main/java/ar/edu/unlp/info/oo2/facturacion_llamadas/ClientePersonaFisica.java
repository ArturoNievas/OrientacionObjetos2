package ar.edu.unlp.info.oo2.facturacion_llamadas;

public class ClientePersonaFisica extends Cliente {
	private static double DESCUENTO_LLAMADAS = 0;

	private String dni;

	protected ClientePersonaFisica(String nombre, String numeroTelefono, String dni) {
		super(nombre, numeroTelefono);
		this.dni = dni;
	}

	public String getDNI() {
		return dni;
	}

	@Override
	public double getDescuentoEnLlamadas() {
		return ClientePersonaFisica.DESCUENTO_LLAMADAS;
	}
}
