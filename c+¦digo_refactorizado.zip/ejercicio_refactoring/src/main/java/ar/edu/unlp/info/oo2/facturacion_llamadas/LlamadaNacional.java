package ar.edu.unlp.info.oo2.facturacion_llamadas;

public class LlamadaNacional extends Llamada {
	private static double PRECIO_POR_SEG = 3;
	private static double PRECIO_ESTAB_LLAMADA = 0;

	public LlamadaNacional(String origen, String destino, int duracion) {
		super(origen, destino, duracion);
	}

	@Override
	protected double getMontoPorSegundo() {
		return LlamadaNacional.PRECIO_POR_SEG;
	}

	@Override
	protected double getMontoPorEstablecerLlamada() {
		return LlamadaNacional.PRECIO_ESTAB_LLAMADA;
	}
}
