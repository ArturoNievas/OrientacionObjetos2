package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.SortedSet;

public class GeneradorNumerosStrategyUltimo extends GeneradorNumerosStrategy {
	@Override
	protected String seleccionarLineaLibre(SortedSet<String> lineas) {
		return lineas.last();
	}
}
