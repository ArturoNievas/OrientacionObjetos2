package ar.edu.unlp.info.oo2.facturacion_llamadas;

public abstract class Llamada {
	public static Llamada crearLlamadaNacional(Cliente origen, Cliente destino, int duracion) {
		return new LlamadaNacional(origen.getNumeroTelefono(), destino.getNumeroTelefono(), duracion);
	}

	public static Llamada crearLlamadaInternacional(Cliente origen, Cliente destino, int duracion) {
		return new LlamadaInternacional(origen.getNumeroTelefono(), destino.getNumeroTelefono(), duracion);
	}

	private static double IVA = 0.21;

	private String origen;
	private String destino;
	private int duracion;

	protected Llamada(String origen, String destino, int duracion) {
		this.origen = origen;
		this.destino = destino;
		this.duracion = duracion;
	}

	public String getRemitente() {
		return destino;
	}

	public int getDuracion() {
		return this.duracion;
	}

	public String getOrigen() {
		return origen;
	}

	protected abstract double getMontoPorSegundo();

	protected abstract double getMontoPorEstablecerLlamada();

	public double getMonto() {
		return this.getDuracion() * this.getMontoPorSegundo() * (1 + Llamada.IVA) + this.getMontoPorEstablecerLlamada();
	}
}
