package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.TreeSet;
import java.util.SortedSet;

public class GestorNumerosDisponibles {
	private SortedSet<String> lineas;
	private GeneradorNumerosStrategy generador;

	public GestorNumerosDisponibles() {
		this.lineas = new TreeSet<String>();
		this.generador = new GeneradorNumerosStrategyUltimo();
	}

	public String obtenerNumeroLibre() {
		return this.generador.liberarLinea(lineas);
	}

	/** Escenario 1. */
	public void setGenerador(GeneradorNumerosStrategy generador) {
		this.generador = generador;
	}

	/** Escenario 2. */
	public void cambiarTipoGenerador(String tipo) {
		this.generador = GeneradorNumerosStrategy.crearGenerador(tipo);
	}

	public boolean agregarNumeroTelefono(String lineaTelefonica) {
		return this.lineas.add(lineaTelefonica);
	}
}
