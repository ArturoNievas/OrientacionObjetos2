package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.ArrayList;
import java.util.List;

public abstract class Cliente {
	public static Cliente crearPersonaFisica(String nombre, String numeroTelefono, String dni) {
		return new ClientePersonaFisica(nombre, numeroTelefono, dni);
	}

	public static Cliente crearPersonaJuridica(String razonSocial, String numeroTelefono, String cuit) {
		return new ClientePersonaJuridica(razonSocial, numeroTelefono, cuit);
	}

	private List<Llamada> llamadas;
	private String nombre;
	private String numeroTelefono;

	protected Cliente(String nombre, String numeroTelefono) {
		this.nombre = nombre;
		this.numeroTelefono = numeroTelefono;
		this.llamadas = new ArrayList<Llamada>();
	}

	protected abstract double getDescuentoEnLlamadas();

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}

	public Llamada agregarLlamada(Llamada llamada) {
		this.llamadas.add(llamada);
		return llamada;
	}

	public double calcularMontoTotalLlamadas() {
		return this.llamadas.stream().mapToDouble(llamada -> llamada.getMonto() * (1 - this.getDescuentoEnLlamadas()))
				.sum();
	}
}
